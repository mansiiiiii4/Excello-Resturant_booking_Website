<?php
session_start();
?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Homemade Restaurant, about, Learn Cooking Online, 1, 2, 1, Asian Food, m fe ia st hand">
    <meta name="description" content="">
    <title>home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="home.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.19.2, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Comfortaa:300,400,500,600,700">
    
    
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"url": "/",
		"logo": "images/Whitelogo-nobackground.png",
		"sameAs": [
				"https://facebook.com/excello",
				"https://twitter.com/excello",
				"https://instagram.com/excello"
		]
}</script>
    <meta name="theme-color" content="#fe7606">
    <link rel="canonical" href="/">
    <meta name="twitter:site" content="@">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="home">
    <meta name="twitter:description" content="">
    <meta property="og:title" content="home">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="https://website2967332.nicepage.io/index.php?version=28feaf5c-4072-4a80-b2b3-5929668e3f28" data-home-page-title="home" class="u-body u-xl-mode" data-lang="en">
    <header class="u-clearfix u-custom-color-2 u-header u-sticky u-header" id="sec-af6e">
      <div class="u-clearfix u-sheet u-sheet-1">
        <a href="index.php" class="u-image u-logo u-image-1" data-image-width="1920" data-image-height="637" title="home">
          <img src="images/Whitelogo-nobackground.png" class="u-logo-image u-logo-image-1">
        </a>
        <a href="logout.php" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-1">Logout</a><!-- add logout option -->
        <a href="./about-html/index.html" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-2">About Us</a><!-- remove this option -->
        <a href="signup.php" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-3">Login/SignUp</a>
        <a href="https://docs.google.com/forms/d/e/1FAIpQLSfjjKktQz1nF2IYSrmLbU2U2XfQOdp4LFA8950jD2AN-VSdvA/viewform?usp=sf_link" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-4">Hiring</a>
        <a href="booking.php" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-5">Reservation</a>
        <a href="menu.html" class="u-btn u-button-style u-custom-font u-heading-font u-none u-text-hover-grey-15 u-btn-6">Menu</a>
      </div></header>
    <section class="u-align-left u-clearfix u-color-scheme-u11 u-color-style-multicolor-1 u-image u-section-1" id="carousel_c8fc" data-image-width="1648" data-image-height="1080">
      <div class="u-clearfix u-sheet u-valign-middle-xs u-sheet-1">
        <h2 class="u-align-justify u-text u-text-1"><b>Excello<span style="font-weight: 400;">
              <span style="font-weight: 700;">
                <span style="font-style: italic;"></span>
              </span>
            </span></b>
        </h2>
        <p class="u-align-justify u-text u-text-body-alt-color u-text-2"> Where every​ flavor tells a story.</p>
      </div>
    </section>
    <section class="u-clearfix u-white u-section-2" id="sec-b5fc">
      <div class="u-container-style u-custom-color-2 u-group u-group-1">
        <div class="u-container-layout u-container-layout-1"></div>
      </div>
      <div class="u-container-style u-custom-color-1 u-group u-group-2">
        <div class="u-container-layout u-container-layout-2"></div>
      </div>
      <div class="u-clearfix u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-container-style u-layout-cell u-left-cell u-size-20 u-layout-cell-1">
              <div class="u-container-layout u-container-layout-3">
                <img src="images/g288293c9a92f248938127ecd4fbb2dd2013001a8566174e18ea8cf50589f6e828a4f11560297a41ecf445c8c07b9a404a6c011f6d20df07f0f21f053cbfeeb5e_1280.jpg" alt="" class="u-expanded-width u-image u-image-default u-image-1" data-image-width="960" data-image-height="1280">
              </div>
            </div>
            <div class="u-align-center u-container-style u-layout-cell u-size-20 u-layout-cell-2">
              <div class="u-container-layout u-container-layout-4">
                <a href="https://www.excello.com/menu" class="u-align-center u-border-none u-btn u-button-style u-custom-font u-heading-font u-none u-text-grey-70 u-btn-1">
                  <span style="font-size: 6rem; font-weight: 700;" class="u-text-custom-color-2"> Menu</span>
                  <br>
                </a>
              </div>
            </div>
            <div class="u-container-style u-layout-cell u-right-cell u-size-20 u-layout-cell-3">
              <div class="u-container-layout u-valign-bottom-lg u-valign-bottom-md u-valign-bottom-xl u-valign-top-sm u-valign-top-xs u-container-layout-5">
                <img src="images/pexels-esma-zer-12885013.jpg" alt="" class="u-expanded-width u-image u-image-default u-image-2" data-image-width="810" data-image-height="1080">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-section-3" id="carousel_26cd">
      <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
        <div class="u-gutter-0 u-layout">
          <div class="u-layout-row">
            <div class="u-container-style u-image u-layout-cell u-left-cell u-size-25 u-image-1" data-image-width="810" data-image-height="1080">
              <div class="u-container-layout u-container-layout-1"></div>
            </div>
            <div class="u-align-center u-container-style u-custom-color-1 u-layout-cell u-size-10 u-layout-cell-2">
              <div class="u-container-layout u-valign-middle u-container-layout-2">
                <h1 class="u-custom-font u-heading-font u-text u-text-custom-color-2 u-text-default u-text-1">s<br>e<br>e<br>
                  <br>y<br>o<br>u<br>
                </h1>
              </div>
            </div>
            <div class="u-container-style u-image u-layout-cell u-right-cell u-size-25 u-image-2" data-image-width="564" data-image-height="854">
              <div class="u-container-layout u-container-layout-3"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-valign-top-lg u-valign-top-xl u-section-4" id="carousel_b63d">
      <div class="u-custom-color-2 u-shape u-shape-rectangle u-shape-1"></div>
      <div class="u-clearfix u-gutter-30 u-layout-wrap u-layout-wrap-1">
        <div class="u-gutter-0 u-layout">
          <div class="u-layout-row">
            <div class="u-align-left u-container-style u-image u-layout-cell u-left-cell u-size-18 u-image-1" src="">
              <div class="u-container-layout" src=""></div>
            </div>
            <div class="u-align-left u-container-style u-image u-layout-cell u-size-18 u-image-2" src="">
              <div class="u-container-layout" src=""></div>
            </div>
            <div class="u-align-left u-container-style u-layout-cell u-right-cell u-size-24 u-layout-cell-3">
              <div class="u-container-layout u-container-layout-3">
                <h3 class="u-custom-font u-heading-font u-text u-text-custom-color-2 u-text-1">Farm Products</h3>
                <p class="u-text u-text-2"> Every ingredient in our dishes is 100% natural and is picked up fresh from the farm on a daily basis.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-section-5" id="sec-d07b">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <h2 class="u-text u-text-custom-color-1 u-text-default u-text-1">with love</h2>
        <div class="u-expanded-width u-gallery u-layout-grid u-lightbox u-show-text-on-hover u-gallery-1" id="carousel-db69">
          <div class="u-gallery-inner u-gallery-inner-1" role="listbox">
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-1">
              <div class="u-back-slide u-back-slide-1" data-image-width="1619" data-image-height="1080">
                <img src="images/davide-cantelli-jpkfc5_d-DI-unsplash.jpg" alt="" data-image-width="2000" data-image-height="1333" class="u-back-image u-expanded">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-1">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-2">
              <div class="u-back-slide" data-image-width="1792" data-image-height="1080">
                <img class="u-back-image u-expanded" src="images/pexels-min-an-1441122.jpg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-2">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-3">
              <div class="u-back-slide" data-image-width="1620" data-image-height="1080">
                <img class="u-back-image u-expanded" src="images/kelvin-t-AcA8moIiD3g-unsplash.jpg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-3">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-4">
              <div class="u-back-slide" data-image-width="1630" data-image-height="1080">
                <img class="u-back-image u-expanded" src="images/pexels-pixabay-47062.jpg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-4">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-5">
              <div class="u-back-slide" data-image-width="1607" data-image-height="1080">
                <img class="u-back-image u-expanded" src="images/shiv-singh-Vj-J5xNjnxA-unsplash.jpg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-5">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item u-shape-rectangle u-gallery-item-6">
              <div class="u-back-slide" data-image-width="1677" data-image-height="1080">
                <img class="u-back-image u-expanded" src="images/pexels-min-che-6879442.jpg">
              </div>
              <div class="u-align-center u-over-slide u-shading u-over-slide-6">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-custom-color-1 u-section-6" id="sec-8e6b">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <h6 class="u-custom-font u-font-montserrat u-text u-text-default u-text-1"> What People Say?</h6>
        <div id="carousel-5989" data-interval="5000" data-u-ride="carousel" class="u-carousel u-expanded-width-sm u-expanded-width-xs u-slider u-slider-1">
          <ol class="u-absolute-hcenter u-carousel-indicators u-carousel-indicators-1">
            <li data-u-target="#carousel-5989" class="u-active u-grey-50 u-shape-circle" data-u-slide-to="0" style="width: 10px; height: 10px;"></li>
            <li data-u-target="#carousel-5989" class="u-grey-50 u-shape-circle" data-u-slide-to="1" style="width: 10px; height: 10px;"></li>
            <li data-u-target="#carousel-5989" class="u-grey-50 u-shape-circle" data-u-slide-to="2" style="width: 10px; height: 10px;"></li>
          </ol>
          <div class="u-carousel-inner" role="listbox">
            <div class="u-active u-align-center u-carousel-item u-container-style u-slide">
              <div class="u-container-layout u-container-layout-1">
                <p class="u-large-text u-text u-text-variant u-text-2"> Searching for places to eat in the local area and this place popped up. I don’t normally leave reviews but I feel compelled as the food was absolutely exquisite. The&nbsp;desserts here may be the best I’ve ever had!</p>
                <h4 class="u-text u-text-default u-text-3">Connor Quinn<br>
                </h4>
                <h6 class="u-text u-text-default u-text-4">Happy ​Customer</h6>
              </div>
            </div>
            <div class="u-align-center u-carousel-item u-container-style u-slide">
              <div class="u-container-layout u-container-layout-2">
                <p class="u-large-text u-text u-text-variant u-text-5"> Amazing food! The whole experience from start to finish is great staff is always so friendly and kind. The food can’t get better and the prices are fair for the portion size. Always a great spot to get great food.</p>
                <h4 class="u-text u-text-default u-text-6"> Jack Alvarez<br>
                </h4>
                <h6 class="u-text u-text-default u-text-7"> Happy Customer</h6>
              </div>
            </div>
            <div class="u-carousel-item u-container-style u-slide u-carousel-item-3">
              <div class="u-container-layout u-container-layout-3">
                <p class="u-align-center u-large-text u-text u-text-variant u-text-8"> It’s a great experience. The ambiance is very welcoming and charming. Amazing beverages, food and service. Staff are extremely knowledgeable and make great recommendations.</p>
                <h4 class="u-text u-text-default u-text-9"> Seamas Ellen<br>
                </h4>
                <h6 class="u-text u-text-default u-text-10">Happy Costumer</h6>
              </div>
            </div>
          </div>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-prev u-spacing-10 u-text-grey-50 u-carousel-control-1" href="#carousel-5989" role="button" data-u-slide="prev">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.847 451.847"><path d="M97.141,225.92c0-8.095,3.091-16.192,9.259-22.366L300.689,9.27c12.359-12.359,32.397-12.359,44.751,0
c12.354,12.354,12.354,32.388,0,44.748L173.525,225.92l171.903,171.909c12.354,12.354,12.354,32.391,0,44.744
c-12.354,12.365-32.386,12.365-44.745,0l-194.29-194.281C100.226,242.115,97.141,234.018,97.141,225.92z"></path></svg>
            </span>
          </a>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-next u-spacing-10 u-text-grey-50 u-carousel-control-2" href="#carousel-5989" role="button" data-u-slide="next">
            <span aria-hidden="true">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 451.846 451.847"><path d="M345.441,248.292L151.154,442.573c-12.359,12.365-32.397,12.365-44.75,0c-12.354-12.354-12.354-32.391,0-44.744
L278.318,225.92L106.409,54.017c-12.354-12.359-12.354-32.394,0-44.748c12.354-12.359,32.391-12.359,44.75,0l194.287,194.284
c6.177,6.18,9.262,14.271,9.262,22.366C354.708,234.018,351.617,242.115,345.441,248.292z"></path></svg>
            </span>
          </a>
        </div>
      </div>
      <style data-mode="XXL">@media (max-width: 0px) {
   .u-section-6 {
    background-image: none;
  }
  .u-section-6 .u-sheet-1 {
    min-height: 579px;
  }
  .u-section-6 .u-slider-1 {
    min-height: 480px;
    width: 763px;
    margin-top: 50px;
    margin-bottom: 50px;
    margin-left: auto;
    margin-right: auto;
  }
  .u-section-6 .u-carousel-indicators-1 {
    position: absolute;
    bottom: 10px;
    width: auto;
    height: auto;
  }
  .u-section-6 .u-container-layout-1 {
    padding-top: 30px;
    padding-bottom: 30px;
    padding-left: 80px;
    padding-right: 80px;
  }
  .u-block-cc28-18 {
    width: 83px;
    height: 83px;
    background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJtYW4iIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCAyNTYgMjU2IiBzdHlsZT0id2lkdGg6IDI1NnB4OyBoZWlnaHQ6IDI1NnB4OyI+CjxyZWN0IGZpbGw9IiNDNkQ4RTEiIHdpZHRoPSIyNTYiIGhlaWdodD0iMjU2Ii8+CjxwYXRoIGZpbGw9IiM3Rjk2QTYiIGQ9Ik0xNzIuNiw5My40YzExLjYtNDQuNy0xMS4yLTQ4LjYtMTEuNy00OC4xYy0yMi40LTMxLjMtOTAuMy0xNi44LTc3LjQsNDguMWMtMTMuMy0yLjQtMS44LDMxLjYsMy43LDMyLjEKCWMwLDAsMCwwLDAsMGMwLjIsMCwwLjMsMCwwLjUtMC4xYzE0LjQsNDkuNyw2Mi43LDUwLjIsODAuNywwQzE3Mi4zLDEyNy4zLDE4Ni41LDkzLjMsMTcyLjYsOTMuNHoiLz4KPHBhdGggZmlsbD0iIzdGOTZBNiIgZD0iTTIwNS40LDE3Ny45Yy0yNC02LjEtNDMuNS0xOS44LTQzLjUtMTkuOGwtMjAuNiw2NC44bC04LTIyLjhjMTkuNy0yNy41LTMwLjMtMjcuNS0xMC42LDBsLTgsMjIuOEw5NCwxNTguMQoJYzAsMC0xOS41LDEzLjctNDMuNSwxOS44QzMyLjcsMTgyLjUsMzAsMjU2LDMwLDI1NmgxOTZDMjI2LDI1NiwyMjMuMywxODIuNSwyMDUuNCwxNzcuOXoiLz4KPC9zdmc+Cg==");
    background-position: 50% 50%;
    margin-top: 0;
    margin-bottom: 0;
    margin-left: auto;
    margin-right: auto;
  }
  .u-section-6 .u-text-2 {
    margin-top: 20px;
    margin-left: 0;
    margin-right: 0;
    margin-bottom: 0;
    font-size: 1.25rem;
  }
  .u-section-6 .u-text-3 {
    font-weight: 700;
    margin-top: 35px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0;
  }
  .u-section-6 .u-text-4 {
    font-size: 1rem;
    font-weight: 400;
    margin-top: 15px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0;
  }
  .u-section-6 .u-container-layout-2 {
    padding-top: 30px;
    padding-bottom: 30px;
    padding-left: 80px;
    padding-right: 80px;
  }
  .u-block-cc28-21 {
    width: 83px;
    height: 83px;
    background-image: url("data:image/svg+xml;base64,PHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJtYW4iIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCAyNTYgMjU2IiBzdHlsZT0id2lkdGg6IDI1NnB4OyBoZWlnaHQ6IDI1NnB4OyI+CjxyZWN0IGZpbGw9IiNDNkQ4RTEiIHdpZHRoPSIyNTYiIGhlaWdodD0iMjU2Ii8+CjxwYXRoIGZpbGw9IiM3Rjk2QTYiIGQ9Ik0xNzIuNiw5My40YzExLjYtNDQuNy0xMS4yLTQ4LjYtMTEuNy00OC4xYy0yMi40LTMxLjMtOTAuMy0xNi44LTc3LjQsNDguMWMtMTMuMy0yLjQtMS44LDMxLjYsMy43LDMyLjEKCWMwLDAsMCwwLDAsMGMwLjIsMCwwLjMsMCwwLjUtMC4xYzE0LjQsNDkuNyw2Mi43LDUwLjIsODAuNywwQzE3Mi4zLDEyNy4zLDE4Ni41LDkzLjMsMTcyLjYsOTMuNHoiLz4KPHBhdGggZmlsbD0iIzdGOTZBNiIgZD0iTTIwNS40LDE3Ny45Yy0yNC02LjEtNDMuNS0xOS44LTQzLjUtMTkuOGwtMjAuNiw2NC44bC04LTIyLjhjMTkuNy0yNy41LTMwLjMtMjcuNS0xMC42LDBsLTgsMjIuOEw5NCwxNTguMQoJYzAsMC0xOS41LDEzLjctNDMuNSwxOS44QzMyLjcsMTgyLjUsMzAsMjU2LDMwLDI1NmgxOTZDMjI2LDI1NiwyMjMuMywxODIuNSwyMDUuNCwxNzcuOXoiLz4KPC9zdmc+Cg==");
    background-position: 50% 50%;
    margin-top: 0;
    margin-bottom: 0;
    margin-left: auto;
    margin-right: auto;
  }
  .u-section-6 .u-text-5 {
    margin-top: 20px;
    margin-left: 0;
    margin-right: 0;
    margin-bottom: 0;
    font-size: 1.25rem;
  }
  .u-section-6 .u-text-6 {
    font-weight: 700;
    margin-top: 35px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0;
  }
  .u-section-6 .u-text-7 {
    font-size: 1rem;
    font-weight: 400;
    margin-top: 15px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0;
  }
  .u-section-6 .u-carousel-control-1 {
    width: 43px;
    height: 43px;
    background-image: none;
  }
  .u-section-6 .u-carousel-control-2 {
    width: 43px;
    height: 43px;
    background-image: none;
    left: auto;
    position: absolute;
    right: 0;
  }
}</style>
    </section>
    
    
    <footer class="u-black u-clearfix u-footer" id="sec-da85"><div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-left u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1">
                <div class="u-container-layout u-container-layout-1">
                  <a href="https://www.excello.com/about" class="u-active-none u-border-none u-btn u-button-style u-custom-font u-heading-font u-hover-none u-none u-btn-1">Our Story</a>
                  <a href="https://www.excello.com/hiring" class="u-border-active-palette-2-base u-border-hover-palette-1-base u-border-none u-btn u-button-style u-custom-font u-heading-font u-none u-text-white u-btn-2">Hiring</a>
                </div>
              </div>
              <div class="u-align-left u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-valign-top u-container-layout-2">
                  <h6 class="u-text u-text-1">Stay in Touch</h6>
                  <div class="u-align-left u-social-icons u-spacing-10 u-social-icons-1">
                    <a class="u-social-url" title="facebook" target="_blank" href="https://facebook.com/excello"><span class="u-icon u-social-facebook u-social-icon u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xlink:href="#svg-47f0"></use></svg><svg class="u-svg-content" viewBox="0 0 112 112" x="0" y="0" id="svg-47f0"><path fill="currentColor" d="M75.5,28.8H65.4c-1.5,0-4,0.9-4,4.3v9.4h13.9l-1.5,15.8H61.4v45.1H42.8V58.3h-8.8V42.4h8.8V32.2
c0-7.4,3.4-18.8,18.8-18.8h13.8v15.4H75.5z"></path></svg></span>
                    </a>
                    <a class="u-social-url" title="twitter" target="_blank" href="https://twitter.com/excello"><span class="u-icon u-social-icon u-social-twitter u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xlink:href="#svg-f861"></use></svg><svg class="u-svg-content" viewBox="0 0 112 112" x="0" y="0" id="svg-f861"><path fill="currentColor" d="M92.2,38.2c0,0.8,0,1.6,0,2.3c0,24.3-18.6,52.4-52.6,52.4c-10.6,0.1-20.2-2.9-28.5-8.2
	c1.4,0.2,2.9,0.2,4.4,0.2c8.7,0,16.7-2.9,23-7.9c-8.1-0.2-14.9-5.5-17.3-12.8c1.1,0.2,2.4,0.2,3.4,0.2c1.6,0,3.3-0.2,4.8-0.7
	c-8.4-1.6-14.9-9.2-14.9-18c0-0.2,0-0.2,0-0.2c2.5,1.4,5.4,2.2,8.4,2.3c-5-3.3-8.3-8.9-8.3-15.4c0-3.4,1-6.5,2.5-9.2
	c9.1,11.1,22.7,18.5,38,19.2c-0.2-1.4-0.4-2.8-0.4-4.3c0.1-10,8.3-18.2,18.5-18.2c5.4,0,10.1,2.2,13.5,5.7c4.3-0.8,8.1-2.3,11.7-4.5
	c-1.4,4.3-4.3,7.9-8.1,10.1c3.7-0.4,7.3-1.4,10.6-2.9C98.9,32.3,95.7,35.5,92.2,38.2z"></path></svg></span>
                    </a>
                    <a class="u-social-url" title="instagram" target="_blank" href="https://instagram.com/excello"><span class="u-icon u-social-icon u-social-instagram u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xlink:href="#svg-0153"></use></svg><svg class="u-svg-content" viewBox="0 0 112 112" x="0" y="0" id="svg-0153"><path fill="currentColor" d="M55.9,32.9c-12.8,0-23.2,10.4-23.2,23.2s10.4,23.2,23.2,23.2s23.2-10.4,23.2-23.2S68.7,32.9,55.9,32.9z
	 M55.9,69.4c-7.4,0-13.3-6-13.3-13.3c-0.1-7.4,6-13.3,13.3-13.3s13.3,6,13.3,13.3C69.3,63.5,63.3,69.4,55.9,69.4z"></path><path fill="#FFFFFF" d="M79.7,26.8c-3,0-5.4,2.5-5.4,5.4s2.5,5.4,5.4,5.4c3,0,5.4-2.5,5.4-5.4S82.7,26.8,79.7,26.8z"></path><path fill="currentColor" d="M78.2,11H33.5C21,11,10.8,21.3,10.8,33.7v44.7c0,12.6,10.2,22.8,22.7,22.8h44.7c12.6,0,22.7-10.2,22.7-22.7
	V33.7C100.8,21.1,90.6,11,78.2,11z M91,78.4c0,7.1-5.8,12.8-12.8,12.8H33.5c-7.1,0-12.8-5.8-12.8-12.8V33.7
	c0-7.1,5.8-12.8,12.8-12.8h44.7c7.1,0,12.8,5.8,12.8,12.8V78.4z"></path></svg></span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="u-align-left u-border-1 u-border-white u-expanded-width u-line u-line-horizontal u-opacity u-opacity-25 u-line-1"></div>
      </div></footer>
    
</body></html>